
require.config({

    paths: {
        'underscore': '../../node_modules/underscore/underscore', // AMD support,
        'als' : '../../lib/amd/als-module', // conversion : node r -convert ..\..\..\lib\als-module-commonjs ..\..\..\lib\amd
        'angular' : './lib/angular.min',
        'app' : './app'
    },

    shim: {
        als: {
            export: 'als'
        }
    }

    /*shim: {
        underscore: {
            //exports: 'underscore'
        },
        als: {
            deps: ['underscore'],
            export: "als"
        }
    }*/
});


//the "main" function to bootstrap your code
require([
    'underscore',
    'als'
], function (_, als) {   // or, you could use these deps in a separate module using define

    if (!_) console.error('_');
    window.als = als;

});